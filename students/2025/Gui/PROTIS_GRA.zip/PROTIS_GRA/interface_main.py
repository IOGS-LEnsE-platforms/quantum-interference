"""
*************************************************
@author: Della Vittoria Louis
*************************************************

Ce programme est le code principal de l'interface graphique
qui regroupe toutes les fonctionnalités de l'application.

*************************************************

 *  Solec / https://solecgroup.wordpress.com/
 *  ProTIS / https://lense.institutoptique.fr/

"""

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QFont, QIcon
import pyqtgraph as pg
import pyqtgraph.exporters
from serial import Serial, SerialException
import serial
import serial.tools.list_ports
import random
import time
import interface_piezo
import interface_g2_3det
import struct
import interface_g2_2det
import interface_jauges
# from class_piezo import *

class Ui_MainWindow(object):
    def __init__(self):
        # Initialisation des fenêtres secondaires
        self.PiezoWindow = QtWidgets.QMainWindow()
        self.w = interface_piezo.Ui_MainWindow2()
        self.w.setupUi(self.PiezoWindow)

        self.G2Window = QtWidgets.QMainWindow()
        self.w2 = interface_g2_3det.Ui_MainWindow()
        self.w2.setupUi(self.G2Window)

        # self.G2_2detWindow = QtWidgets.QMainWindow()
        # self.w3 = interface_g2_2det.Ui_MainWindow()
        # self.w3.setupUi(self.G2_2detWindow)

        self.jauges_Window = QtWidgets.QMainWindow()
        self.w4 = interface_jauges.Ui_MainWindow()
        self.w4.setupUi(self.jauges_Window)

        # Variables d'instance
        self.use_serial = True  # Défaut : utiliser la Nucleo si disponible
        self.flag = False
        self.counter_points = 0
        self.flag_cursor = True
        self.flag_timer = False
        self.flag_timer2 = False
        self.stack = 0
        self.interval = 100
        self.timer = QtCore.QTimer()
        self.timer.start(self.interval)  # Mise à jour toutes les 100 ms
        (
            self.data_buffer,
            self.data_buffer_B,
            self.data_buffer_C,
            self.data_buffer_AB,
            self.data_buffer_AC,
            self.data_buffer_ABC,
        ) = ([], [], [], [], [], [])

    def setupUi(self, MainWindow):
        # Configuration de la fenêtre principale
        self.main_window = MainWindow
        MainWindow.resize(1200, 848)
        sizePolicy = QtWidgets.QSizePolicy(
            QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding
        )
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(MainWindow.sizePolicy().hasHeightForWidth())
        MainWindow.setSizePolicy(sizePolicy)
        MainWindow.setStyleSheet("background-color: white")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        # Configuration des frames et des layouts
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(29, 79, 501, 371))
        self.frame.setStyleSheet(
            "border-radius: 10px;\n" "background-color: lightgrey\n"
        )
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.verticalLayoutWidget = QtWidgets.QWidget(self.frame)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(10, 10, 481, 351))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")

        self.frame_2 = QtWidgets.QFrame(self.centralwidget)
        self.frame_2.setGeometry(QtCore.QRect(30, 460, 241, 331))
        self.frame_2.setStyleSheet(
            "\n" "border-radius: 10px;\n" "background-color: lightgrey\n"
        )
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.verticalLayoutWidget_5 = QtWidgets.QWidget(self.frame_2)
        self.verticalLayoutWidget_5.setGeometry(QtCore.QRect(10, 10, 221, 311))
        self.verticalLayoutWidget_5.setObjectName("verticalLayoutWidget_5")
        self.verticalLayout_6 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_5)
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.verticalLayout_5 = QtWidgets.QVBoxLayout()
        self.verticalLayout_5.setObjectName("verticalLayout_5")

        # Configuration des labels et des boutons
        self.label = QtWidgets.QLabel(self.verticalLayoutWidget_5)
        self.label.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.label.setAutoFillBackground(False)
        self.label.setStyleSheet(
            "QLabel {\n"
            "    font-size: 16px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid orange; /* Bordure verte */\n"
            "    border-radius: 10px; /* Coins arrondis */\n"
            "    padding: 5px; /* Espacement interne */\n"
            "}"
        )
        self.label.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.label.setFrameShadow(QtWidgets.QFrame.Plain)
        self.label.setLineWidth(0)
        self.label.setMidLineWidth(0)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setWordWrap(False)
        self.label.setObjectName("label")
        self.verticalLayout_5.addWidget(self.label)

        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget_5)
        self.pushButton.clicked.connect(self.w2.calculate_g2)
        self.pushButton.clicked.connect(self.test2)
        self.pushButton.setEnabled(True)
        self.pushButton.setStyleSheet(
            "QPushButton {\n"
            "    background-color: #4CAF50;\n"
            "    color: white;\n"
            "    font-size: 14px;\n"
            "    font-weight: bold;\n"
            "    border: 2px solid #2E7D32;\n"
            "    border-radius: 5px;\n"
            "    padding: 1px;\n"
            "}\n"
            "\n"
            "QPushButton:hover {\n"
            "    background-color: #45a049;\n"
            "    border-color: #1B5E20;\n"
            "}\n"
            "\n"
            "QPushButton:pressed {\n"
            "    background-color: #388E3C;\n"
            "    border-color: #1B5E20;\n"
            "}\n"
            "\n"
            ""
        )
        self.pushButton.setIconSize(QtCore.QSize(16, 16))
        self.pushButton.setAutoDefault(False)
        self.pushButton.setDefault(False)
        self.pushButton.setFlat(False)
        self.pushButton.setObjectName("pushButton")
        self.verticalLayout_5.addWidget(self.pushButton)

        self.pushButton_3 = QtWidgets.QPushButton(self.verticalLayoutWidget_5)
        self.pushButton_3.clicked.connect(self.input_time)
        self.pushButton_3.setStyleSheet(
            "QPushButton {\n"
            "    background-color: #4CAF50;\n"
            "    color: white;\n"
            "    font-size: 14px;\n"
            "    font-weight: bold;\n"
            "    border: 2px solid #2E7D32;\n"
            "    border-radius: 5px;\n"
            "    padding: 1px;\n"
            "}\n"
            "\n"
            "QPushButton:hover {\n"
            "    background-color: #45a049;\n"
            "    border-color: #1B5E20;\n"
            "}\n"
            "\n"
            "QPushButton:pressed {\n"
            "    background-color: #388E3C;\n"
            "    border-color: #1B5E20;\n"
            "}\n"
            "\n"
            "QPushButton:disabled {\n"
            "    background-color: gray;\n"
            "    color: darkgray;\n"
            "}"
        )
        self.pushButton_3.setObjectName("pushButton_3")
        self.verticalLayout_5.addWidget(self.pushButton_3)

        self.pushButton_2 = QtWidgets.QPushButton(self.verticalLayoutWidget_5)
        self.pushButton_2.setStyleSheet(
            "QPushButton {\n"
            "    background-color: #4CAF50;\n"
            "    color: white;\n"
            "    font-size: 14px;\n"
            "    font-weight: bold;\n"
            "    border: 2px solid #2E7D32;\n"
            "    border-radius: 5px;\n"
            "    padding: 1px;\n"
            "}\n"
            "\n"
            "QPushButton:hover {\n"
            "    background-color: #45a049;\n"
            "    border-color: #1B5E20;\n"
            "}\n"
            "\n"
            "QPushButton:pressed {\n"
            "    background-color: #388E3C;\n"
            "    border-color: #1B5E20;\n"
            "}\n"
            "\n"
            "QPushButton:disabled {\n"
            "    background-color: gray;\n"
            "    color: darkgray;\n"
            "}"
        )
        self.pushButton_2.setObjectName("pushButton_2")
        # self.pushButton_2.clicked.connect(self.test2)
        self.verticalLayout_5.addWidget(self.pushButton_2)

        self.pushButton_4 = QtWidgets.QPushButton(self.verticalLayoutWidget_5)
        self.pushButton_4.clicked.connect(self.reboot)
        self.pushButton_4.setStyleSheet(
            "QPushButton {\n"
            "    background-color: #4358f7;\n"
            "    color: white;\n"
            "    font-size: 14px;\n"
            "    font-weight: bold;\n"
            "    border: 2px solid #2a41f5;\n"
            "    border-radius: 5px;\n"
            "    padding: 1px;\n"
            "}\n"
            "\n"
            "QPushButton:hover {\n"
            "    background-color: #2a41f5;\n"
            "    border-color: #1B5E20;\n"
            "}\n"
            "\n"
            "QPushButton:pressed {\n"
            "    background-color: #388E3C;\n"
            "    border-color: #1B5E20;\n"
            "}\n"
            "\n"
            "QPushButton:disabled {\n"
            "    background-color: gray;\n"
            "    color: darkgray;\n"
            "}"
        )
        self.pushButton_4.setObjectName("pushButton_4")
        self.verticalLayout_5.addWidget(self.pushButton_4)

        self.pushButton_5 = QtWidgets.QPushButton(self.verticalLayoutWidget_5)
        self.pushButton_5.clicked.connect(self.export_plots)
        self.pushButton_5.setStyleSheet(
            "QPushButton {\n"
            "    background-color: #4CAF50;\n"
            "    color: white;\n"
            "    font-size: 14px;\n"
            "    font-weight: bold;\n"
            "    border: 2px solid #2E7D32;\n"
            "    border-radius: 5px;\n"
            "    padding: 1px;\n"
            "}\n"
            "\n"
            "QPushButton:hover {\n"
            "    background-color: #45a049;\n"
            "    border-color: #1B5E20;\n"
            "}\n"
            "\n"
            "QPushButton:pressed {\n"
            "    background-color: #388E3C;\n"
            "    border-color: #1B5E20;\n"
            "}\n"
            "\n"
            "QPushButton:disabled {\n"
            "    background-color: gray;\n"
            "    color: darkgray;\n"
            "}"
        )
        self.pushButton_5.setObjectName("pushButton_5")
        self.verticalLayout_5.addWidget(self.pushButton_5)

        self.verticalLayout_3.addLayout(self.verticalLayout_5)
        self.verticalLayout_6.addLayout(self.verticalLayout_3)

        self.frame_3 = QtWidgets.QFrame(self.centralwidget)
        self.frame_3.setGeometry(QtCore.QRect(610, 460, 431, 331))
        self.frame_3.setStyleSheet(
            "\n" "border-radius: 10px;\n" "background-color: lightgrey\n"
        )
        self.frame_3.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_3.setObjectName("frame_3")
        self.verticalLayoutWidget_6 = QtWidgets.QWidget(self.frame_3)
        self.verticalLayoutWidget_6.setGeometry(QtCore.QRect(10, 10, 411, 311))
        self.verticalLayoutWidget_6.setObjectName("verticalLayoutWidget_6")
        self.verticalLayout_10 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_6)
        self.verticalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_10.setObjectName("verticalLayout_10")
        self.verticalLayout_4 = QtWidgets.QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")

        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
        self.label_2.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.label_2.setAutoFillBackground(False)
        self.label_2.setStyleSheet(
            "    font-size: 16px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid orange; /* Bordure verte */\n"
            "    border-radius: 10px; /* Coins arrondis */\n"
            "    padding: 5px; /* Espacement interne */"
        )
        self.label_2.setFrameShape(QtWidgets.QFrame.Box)
        self.label_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.label_2.setLineWidth(2)
        self.label_2.setMidLineWidth(1)
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setWordWrap(False)
        self.label_2.setObjectName("label_2")
        self.verticalLayout_4.addWidget(self.label_2)

        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
        self.label_3.setStyleSheet(
            "    font-size: 12px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid grey; /* Bordure verte */\n"
            "    border-radius: 8px; /* Coins arrondis */\n"
            ""
        )
        self.label_3.setObjectName("label_3")
        self.horizontalLayout_2.addWidget(self.label_3)
        spacerItem = QtWidgets.QSpacerItem(
            40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum
        )
        self.horizontalLayout_2.addItem(spacerItem)
        self.verticalLayout_4.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.progressBar = QtWidgets.QProgressBar(self.verticalLayoutWidget_6)
        self.progressBar.setMaximum(1000000)
        self.progressBar.setFormat("%v")
        self.progressBar.setAlignment(QtCore.Qt.AlignCenter)
        self.progressBar.setObjectName("progressBar")
        self.progressBar.setStyleSheet("""
                QProgressBar {
                color: black;
                font-weight: bold;
                border-style: solid;
                border-color: grey;
                border-radius: 7px;
                border-width: 2px;
                text-align: center;
                }

                QProgressBar::chunk {
                width: 4px;
                background-color: green;
                margin: 3px;
                }
                """)
        self.horizontalLayout_3.addWidget(self.progressBar)
        self.verticalLayout_4.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.label_4 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
        self.label_4.setStyleSheet(
            "    font-size: 12px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid grey; /* Bordure verte */\n"
            "    border-radius: 8px; /* Coins arrondis */\n"
            ""
        )
        self.label_4.setObjectName("label_4")
        self.horizontalLayout_4.addWidget(self.label_4)
        spacerItem1 = QtWidgets.QSpacerItem(
            40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum
        )
        self.horizontalLayout_4.addItem(spacerItem1)
        self.verticalLayout_4.addLayout(self.horizontalLayout_4)

        self.verticalLayout_9 = QtWidgets.QVBoxLayout()
        self.verticalLayout_9.setObjectName("verticalLayout_9")
        self.progressBar_2 = QtWidgets.QProgressBar(self.verticalLayoutWidget_6)
        self.progressBar_2.setMaximum(1000000)
        self.progressBar_2.setFormat("%v")
        self.progressBar_2.setAlignment(QtCore.Qt.AlignCenter)
        self.progressBar_2.setObjectName("progressBar_2")
        self.progressBar_2.setStyleSheet("""
                QProgressBar {
                color: black;
                font-weight: bold;
                border-style: solid;
                border-color: grey;
                border-radius: 7px;
                border-width: 2px;
                text-align: center;
                }
                QProgressBar::chunk {
                width: 4px;
                background-color: green;
                margin: 3px;
                }
                """)
        self.verticalLayout_9.addWidget(self.progressBar_2)
        self.verticalLayout_4.addLayout(self.verticalLayout_9)

        self.horizontalLayout_5 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.label_5 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
        self.label_5.setStyleSheet(
            "    font-size: 12px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid grey; /* Bordure verte */\n"
            "    border-radius: 8px; /* Coins arrondis */\n"
            ""
        )
        self.label_5.setObjectName("label_5")
        self.horizontalLayout_5.addWidget(self.label_5)
        spacerItem2 = QtWidgets.QSpacerItem(
            40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum
        )
        self.horizontalLayout_5.addItem(spacerItem2)
        self.verticalLayout_4.addLayout(self.horizontalLayout_5)

        self.verticalLayout_8 = QtWidgets.QVBoxLayout()
        self.verticalLayout_8.setObjectName("verticalLayout_8")
        self.progressBar_3 = QtWidgets.QProgressBar(self.verticalLayoutWidget_6)
        self.progressBar_3.setMaximum(1000000)
        self.progressBar_3.setFormat("%v")
        self.progressBar_3.setAlignment(QtCore.Qt.AlignCenter)
        self.progressBar_3.setObjectName("progressBar_3")
        self.progressBar_3.setStyleSheet("""
                QProgressBar {
                color: black;
                font-weight: bold;
                border-style: solid;
                border-color: grey;
                border-radius: 7px;
                border-width: 2px;
                text-align: center;
                }
                QProgressBar::chunk {
                width: 4px;
                background-color: green;
                margin: 3px;
                }
                """)
        self.verticalLayout_8.addWidget(self.progressBar_3)
        self.verticalLayout_4.addLayout(self.verticalLayout_8)

        self.horizontalLayout_6 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        self.label_6 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
        self.label_6.setStyleSheet(
            "    font-size: 12px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid grey; /* Bordure verte */\n"
            "    border-radius: 8px; /* Coins arrondis */\n"
            ""
        )
        self.label_6.setObjectName("label_6")
        self.horizontalLayout_6.addWidget(self.label_6)
        spacerItem3 = QtWidgets.QSpacerItem(
            40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum
        )
        self.horizontalLayout_6.addItem(spacerItem3)
        self.verticalLayout_4.addLayout(self.horizontalLayout_6)

        self.verticalLayout_7 = QtWidgets.QVBoxLayout()
        self.verticalLayout_7.setObjectName("verticalLayout_7")
        self.progressBar_4 = QtWidgets.QProgressBar(self.verticalLayoutWidget_6)
        self.progressBar_4.setMaximum(1000000)
        self.progressBar_4.setFormat("%v")
        self.progressBar_4.setAlignment(QtCore.Qt.AlignCenter)
        self.progressBar_4.setObjectName("progressBar_4")
        self.progressBar_4.setStyleSheet("""
                QProgressBar {
                color: black;
                font-weight: bold;
                border-style: solid;
                border-color: grey;
                border-radius: 7px;
                border-width: 2px;
                text-align: center;
                }
                QProgressBar::chunk {
                width: 4px;
                background-color: green;
                margin: 3px;
                }
                """)
        self.verticalLayout_7.addWidget(self.progressBar_4)
        self.check_duree = QtWidgets.QCheckBox("Démarrer l'affichage des jauges : Coups et Coïncidences")
        self.check_duree.stateChanged.connect(self.test)
        self.check_duree.setStyleSheet(
            "QCheckBox {\n"
            "    font-size: 12px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid grey; /* Bordure verte */\n"
            "    border-radius: 8px; /* Coins arrondis */\n"
            "}"
        )
        self.verticalLayout_4.addLayout(self.verticalLayout_7)
        self.verticalLayout_4.addWidget(self.check_duree)
        self.verticalLayout_10.addLayout(self.verticalLayout_4)

        self.frame_4 = QtWidgets.QFrame(self.centralwidget)
        self.frame_4.setGeometry(QtCore.QRect(540, 80, 501, 371))
        self.frame_4.setStyleSheet(
            "border-radius: 10px;\n" "background-color: lightgrey\n"
        )
        self.frame_4.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_4.setObjectName("frame_4")
        self.verticalLayoutWidget_2 = QtWidgets.QWidget(self.frame_4)
        self.verticalLayoutWidget_2.setGeometry(QtCore.QRect(10, 10, 481, 351))
        self.verticalLayoutWidget_2.setObjectName("verticalLayoutWidget_2")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_2)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")

        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(110, 10, 851, 41))
        self.label_7.setStyleSheet(
            "    font-size: 15px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid orange; /* Bordure verte */\n"
            "    border-radius: 5px; /* Coins arrondis */\n"
            ""
        )
        self.label_7.setAlignment(QtCore.Qt.AlignCenter)
        self.label_7.setObjectName("label_7")

        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(40, 70, 81, 16))
        self.label_8.setStyleSheet(
            "    font-size: 12px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid grey; /* Bordure verte */\n"
            "    border-radius: 8px; /* Coins arrondis */\n"
            ""
        )
        self.label_8.setObjectName("label_8")

        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(550, 70, 81, 16))
        self.label_9.setStyleSheet(
            "    font-size: 12px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid grey; /* Bordure verte */\n"
            "    border-radius: 8px; /* Coins arrondis */\n"
            ""
        )
        self.label_9.setObjectName("label_9")

        self.frame_5 = QtWidgets.QFrame(self.centralwidget)
        self.frame_5.setGeometry(QtCore.QRect(280, 460, 321, 331))
        self.frame_5.setStyleSheet(
            "\n" "border-radius: 10px;\n" "background-color: lightgrey\n"
        )
        self.frame_5.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_5.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_5.setObjectName("frame_5")
        self.verticalLayoutWidget_7 = QtWidgets.QWidget(self.frame_5)
        self.verticalLayoutWidget_7.setGeometry(QtCore.QRect(10, 10, 301, 311))
        self.verticalLayoutWidget_7.setObjectName("verticalLayoutWidget_7")
        self.verticalLayout_11 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_7)
        self.verticalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_11.setObjectName("verticalLayout_11")

        self.label_10 = QtWidgets.QLabel(self.verticalLayoutWidget_7)
        self.label_10.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.label_10.setAutoFillBackground(False)
        self.label_10.setStyleSheet(
            "    font-size: 16px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid orange; /* Bordure verte */\n"
            "    border-radius: 10px; /* Coins arrondis */\n"
            "    padding: 5px; /* Espacement interne */"
        )
        self.label_10.setFrameShape(QtWidgets.QFrame.Box)
        self.label_10.setFrameShadow(QtWidgets.QFrame.Raised)
        self.label_10.setLineWidth(2)
        self.label_10.setMidLineWidth(1)
        self.label_10.setAlignment(QtCore.Qt.AlignCenter)
        self.label_10.setWordWrap(False)
        self.label_10.setObjectName("label_10")
        self.verticalLayout_11.addWidget(self.label_10)

        self.label_11 = QtWidgets.QLabel(self.verticalLayoutWidget_7)
        self.label_11.setStyleSheet(
            "    font-size: 12px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid grey; /* Bordure verte */\n"
            "    border-radius: 8px; /* Coins arrondis */\n"
            ""
        )
        self.label_11.setObjectName("label_11")
        self.verticalLayout_11.addWidget(self.label_11)

        self.label_12 = QtWidgets.QLabel(self.verticalLayoutWidget_7)
        self.label_12.setStyleSheet(
            "    font-size: 12px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid grey; /* Bordure verte */\n"
            "    border-radius: 8px; /* Coins arrondis */\n"
            ""
        )
        self.label_12.setObjectName("label_12")
        self.verticalLayout_11.addWidget(self.label_12)

        self.label_13 = QtWidgets.QLabel(self.verticalLayoutWidget_7)
        self.label_13.setStyleSheet(
            "    font-size: 12px;\n"
            "    font-weight: bold;\n"
            "    color: white;\n"
            "    background-color: grey;\n"
            "    border: 2px solid grey; /* Bordure verte */\n"
            "    border-radius: 8px; /* Coins arrondis */\n"
            ""
        )
        self.label_13.setObjectName("label_13")
        self.verticalLayout_11.addWidget(self.label_13)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1427, 36))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        ## Graphiques ##
        # Créer un QTabWidget
        self.tabs = QtWidgets.QTabWidget()

        # Créer les onglets
        self.tab1 = QtWidgets.QWidget()
        self.tab2 = QtWidgets.QWidget()
        self.tab3 = QtWidgets.QWidget()

        # Ajouter les onglets au QTabWidget
        self.tabs.addTab(self.tab1, "Détecteur A")
        self.tabs.addTab(self.tab2, "Détecteur B")
        self.tabs.addTab(self.tab3, "Détecteur C")

        # Créer des layouts pour chaque onglet
        self.tab1_layout = QtWidgets.QVBoxLayout()
        self.tab2_layout = QtWidgets.QVBoxLayout()
        self.tab3_layout = QtWidgets.QVBoxLayout()

        self.verticalLayout.addWidget(self.tabs)

        # Définir les layouts pour chaque onglet
        self.tab1.setLayout(self.tab1_layout)
        self.tab2.setLayout(self.tab2_layout)
        self.tab3.setLayout(self.tab3_layout)

        self.tabs2 = QtWidgets.QTabWidget()

        self.tab4 = QtWidgets.QWidget()
        self.tab5 = QtWidgets.QWidget()
        self.tab6 = QtWidgets.QWidget()

        self.tabs2.addTab(self.tab4, "Coïncidences AB")
        self.tabs2.addTab(self.tab5, "Coïncidences AC")
        self.tabs2.addTab(self.tab6, "Coïncidences ABC")

        self.tab4_layout = QtWidgets.QVBoxLayout()
        self.tab5_layout = QtWidgets.QVBoxLayout()
        self.tab6_layout = QtWidgets.QVBoxLayout()

        self.tab4.setLayout(self.tab4_layout)
        self.tab5.setLayout(self.tab5_layout)
        self.tab6.setLayout(self.tab6_layout)

        self.verticalLayout_2.addWidget(self.tabs2)

        self.plot_graph = pg.PlotWidget()
        self.plot_graph.setBackground("k")
        self.plot_graph.setLabel("left", "Valeur de la mesure")
        self.plot_graph.setLabel("bottom", "Temps (x1s)")
        self.plot_graph.setTitle("Comptage des coups en A")
        self.plot_graph.showGrid(x=True, y=True)

        self.curve = self.plot_graph.plot(
            [],
            [],
            pen=pg.mkPen(width=2, color=(127, 127, 0)),
            name="Points de coïncidences",
            symbol="+",
            symbolSize=5,
            symbolBrush="b",
        )

        self.tab1_layout.addWidget(self.plot_graph)

        # self.verticalLayout.addWidget(self.plot_graph)

        self.plot_graph2 = pg.PlotWidget()
        self.plot_graph2.setBackground("k")
        self.plot_graph2.setLabel("left", "Valeur de la mesure")
        self.plot_graph2.setLabel("bottom", "Temps (x1s)")
        self.plot_graph2.setTitle("Comptage des coups en B")
        self.plot_graph2.showGrid(x=True, y=True)

        self.curve2 = self.plot_graph2.plot(
            [],
            [],
            pen=pg.mkPen(width=2, color=(127, 127, 0)),
            name="Points de coïncidences",
            symbol="+",
            symbolSize=5,
            symbolBrush="b",
        )
        self.plot_graph2.setStyleSheet("border: 2px;\n border-radius: 5px;\n")

        self.tab2_layout.addWidget(self.plot_graph2)

        self.plot_graph3 = pg.PlotWidget()
        self.plot_graph3.setBackground("k")
        self.plot_graph3.setLabel("left", "Valeur de la mesure")
        self.plot_graph3.setLabel("bottom", "Temps (x1s)")
        self.plot_graph3.setTitle("Comptage des coups en C")
        self.plot_graph3.showGrid(x=True, y=True)
        self.curve3 = self.plot_graph3.plot(
            [],
            [],
            pen=pg.mkPen(width=2, color=(127, 127, 0)),
            name="Points de coïncidences",
            symbol="+",
            symbolSize=5,
            symbolBrush="b",
        )
        self.plot_graph3.setStyleSheet("border: 2px;\n border-radius: 5px;\n")
        self.tab3_layout.addWidget(self.plot_graph3)

        self.plot_graph4 = pg.PlotWidget()
        self.plot_graph4.setBackground("k")
        self.plot_graph4.setLabel("left", "Valeur de la mesure")
        self.plot_graph4.setLabel("bottom", "Temps (x1s)")
        self.plot_graph4.setTitle("Comptage des coincidences AB")
        self.plot_graph4.showGrid(x=True, y=True)
        self.curve4 = self.plot_graph4.plot(
            [],
            [],
            pen=pg.mkPen(width=2, color=(127, 127, 0)),
            name="Points de coïncidences",
            symbol="+",
            symbolSize=5,
            symbolBrush="b",
        )
        self.plot_graph4.setStyleSheet("border: 2px;\n border-radius: 5px;\n")
        self.tab4_layout.addWidget(self.plot_graph4)

        self.plot_graph5 = pg.PlotWidget()
        self.plot_graph5.setBackground("k")
        self.plot_graph5.setLabel("left", "Valeur de la mesure")
        self.plot_graph5.setLabel("bottom", "Temps (x1s)")
        self.plot_graph5.setTitle("Comptage des coincidences AC")
        self.plot_graph5.showGrid(x=True, y=True)
        self.curve5 = self.plot_graph5.plot(
            [],
            [],
            pen=pg.mkPen(width=2, color=(127, 127, 0)),
            name="Points de coïncidences",
            symbol="+",
            symbolSize=5,
            symbolBrush="b",
        )
        self.plot_graph5.setStyleSheet("border: 2px;\n border-radius: 5px;\n")
        self.tab5_layout.addWidget(self.plot_graph5)

        self.plot_graph6 = pg.PlotWidget()
        self.plot_graph6.setBackground("k")
        self.plot_graph6.setLabel("left", "Valeur de la mesure")
        self.plot_graph6.setLabel("bottom", "Temps (x1s)")
        self.plot_graph6.setTitle("Comptage des coincidences ABC")
        self.plot_graph6.showGrid(x=True, y=True)
        self.curve6 = self.plot_graph6.plot(
            [],
            [],
            pen=pg.mkPen(width=2, color=(127, 127, 0)),
            name="Points de coïncidences",
            symbol="+",
            symbolSize=5,
            symbolBrush="b",
        )
        self.plot_graph6.setStyleSheet("border: 2px;\n border-radius: 5px;\n")
        self.tab6_layout.addWidget(self.plot_graph6)

        ## ToolBar et Menu  ##
        toolbar = QtWidgets.QToolBar("My main toolbar")
        toolbar.setIconSize(QtCore.QSize(16, 16))
        toolbar.setStyleSheet("background-color: transparent")
        toolbar.setOrientation(QtCore.Qt.Horizontal)
        MainWindow.addToolBar(QtCore.Qt.LeftToolBarArea, toolbar)

        button_action2 = QtWidgets.QAction(
            QIcon("joystick.png"), "Piezo &control", MainWindow
        )
        button_action2.setStatusTip(
            "Ouvre une fenêtre de contrôle de la cale piezo-électrique"
        )
        button_action2.triggered.connect(lambda checked: self.show_new_window(self.PiezoWindow, checked))

        button_action2.setCheckable(True)
        toolbar.addAction(button_action2)

        toolbar.addWidget(
            QtWidgets.QLabel("Piezo control", alignment=QtCore.Qt.AlignCenter)
        )

        toolbar.addSeparator()

        button_action = QtWidgets.QAction(
            QIcon("calculator-gray.png"), "Piezo &control", MainWindow
        )
        button_action.setStatusTip("g2 3 détecteurs")
        button_action.triggered.connect(
            lambda checked: self.show_new_window(self.G2Window, checked)
        )
        button_action.setCheckable(True)
        toolbar.addAction(button_action)

        toolbar.addWidget(
            QtWidgets.QLabel("g2 3 détecteurs", alignment=QtCore.Qt.AlignCenter)
        )

        toolbar.addSeparator()

        button_action_4 = QtWidgets.QAction(
            QIcon("calculator-gray.png"), "Piezo &control", MainWindow
        )
        button_action_4.setStatusTip("g2 2 détecteurs")
        button_action_4.triggered.connect(
            lambda checked: self.show_new_window(self.G2_2detWindow, checked)
        )
        button_action_4.setCheckable(True)
        toolbar.addAction(button_action_4)

        toolbar.addWidget(
            QtWidgets.QLabel("g2 2 détecteurs", alignment=QtCore.Qt.AlignCenter)
        )

        toolbar.addSeparator()

        # Supposons que vous avez six graphiques : plot_graph1, plot_graph2, ..., plot_graph6
        self.plot_graphs = [self.plot_graph, self.plot_graph2, self.plot_graph3, self.plot_graph4, self.plot_graph5, self.plot_graph6]
        graph_labels = ["A", "B", "C", "AB", "AC", "ABC"]
        # Créez un QMenu pour le bouton d'action
        cursor_menu = QtWidgets.QMenu("Cursors")

        # Ajoutez des actions pour chaque graphique
        for i, plot_graph in zip(graph_labels, self.plot_graphs):
            action = QtWidgets.QAction(f'Détecteur_'+i, MainWindow)
            action.triggered.connect(lambda checked, plot=plot_graph: self.toggle_cursors(plot))
            cursor_menu.addAction(action)

        # Créez le bouton d'action avec le menu déroulant
        button_action3 = QtWidgets.QAction(QIcon("ruler.png"), "Cursors", MainWindow)
        button_action3.setStatusTip("Curseurs du graphique")
        button_action3.setMenu(cursor_menu)
        toolbar.addAction(button_action3)

        toolbar.addWidget(QtWidgets.QLabel("Cursors", alignment=QtCore.Qt.AlignCenter))

        toolbar.addSeparator()

        button_action5 = QtWidgets.QAction(QIcon("spectrum-emission.png"), "Cursors", MainWindow)
        button_action5.setStatusTip("Ouvrir les jauges de comptage")
        button_action5.triggered.connect(lambda checked: self.show_new_window(self.jauges_Window, checked))
        button_action5.setCheckable(True)
        toolbar.addAction(button_action5)

        toolbar.addWidget(QtWidgets.QLabel("Jauges", alignment=QtCore.Qt.AlignCenter))

        toolbar.addSeparator()

        self.statusBar = QtWidgets.QStatusBar(MainWindow)
        MainWindow.setStatusBar(self.statusBar)

        self.save_menu = QtWidgets.QMenu('Save Menu')
        labels = ['A', 'B', 'C', 'AB', 'AC', 'ABC']
        plot_name = ['plot_graph', 'plot_graph2', 'plot_graph3', 'plot_graph4', 'plot_graph5', 'plot_graph6']
        for label, plot_graph in zip(labels, plot_name):
            action = QtWidgets.QAction(f'Détecteur_'+label, MainWindow)
            action.triggered.connect(lambda checked, label_plot =label, plot=plot_graph: self.export_plots(plot, label_plot))
            self.save_menu.addAction(action)
        self.pushButton_5.setMenu(self.save_menu)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(
            _translate("MainWindow", "Interface TP d'interférence à photons unique")
        )
        self.label.setText(_translate("MainWindow", "Paramètres d'affichage"))
        self.pushButton.setText(_translate("MainWindow", "Démarrer l'acquisition"))
        self.pushButton_3.setText(_translate("MainWindow", "Temps d'échantillonage"))
        self.pushButton_2.setText(_translate("MainWindow", "?"))
        self.pushButton_4.setText(_translate("MainWindow", "Réinitialiser les données"))
        self.pushButton_5.setText(_translate("MainWindow", "Enregistrer l'image"))
        self.label_2.setText(_translate("MainWindow", "Jauges de comptage"))
        self.label_3.setText(_translate("MainWindow", "Jauge A : "))
        self.label_4.setText(_translate("MainWindow", "Jauge B : "))
        self.label_5.setText(_translate("MainWindow", "Jauge C : "))
        self.label_6.setText(_translate("MainWindow", "Jauge ABC : "))
        self.label_7.setText(
            _translate("MainWindow", "Expérience d'interférences à photons unique")
        )
        self.label_8.setText(_translate("MainWindow", "Graphique 1"))
        self.label_9.setText(_translate("MainWindow", "Graphique 2"))
        self.label_10.setText(_translate("MainWindow", "Données des mesures"))
        self.label_11.setText(_translate("MainWindow", f'Nombres de points : {self.counter_points}'))
        self.label_12.setText(_translate("MainWindow", "Temps d'échantillonage : 10 ms"))
        self.label_13.setText(_translate("MainWindow", "Temps d'acquisition : 10 s"))

    def show_new_window(self, window, checked):
        if checked:
            window.show()

    def update_plot(self, value):
        """Met à jour le graphique et le compteur de points"""
        self.data_buffer.append(value)
        self.curve.setData(range(len(self.data_buffer)), self.data_buffer)
        self.label_11.setText(f'Nombres de points: {self.class_Data.counter}')

    def export_plots(self, plot:str, label:str):
        """Exporter les graphiques sous forme d'images PNG
        """
        self.stack+=1
        graph_to_export=getattr(self, plot)
        exporter = pg.exporters.ImageExporter(graph_to_export.plotItem)
        # save to file
        exporter.export(f'{self.stack}_{label}_coincidences.png')

    def input_time(self):
        """Définir le temps d'échantillonage
        """
        val, ok = QtWidgets.QInputDialog.getText(self.main_window, "Choix du temps d'échantillonage", 'Entrer la valeur choisie (ms):')
        if ok:
            try:
                self.interval = int(val)
                if self.interval > 0:
                    self.timer.setInterval(self.interval)
                    self.label_12.setText(f"Temps d'échantillonage: {self.interval} ms")
                else:
                    QtWidgets.QMessageBox.warning(self, 'Invalid Input', 'Please enter a positive integer.')
            except ValueError:
                QtWidgets.QMessageBox.warning(self, 'Invalid Input', 'Please enter a valid integer.')

    def input_time_2(self):
        val, ok = QtWidgets.QInputDialog.getText(self, 'Input Dialog', 'Enter time interval (ms):')
        if ok:
            try:
                interval = int(val)
                self.stop_after_time = interval  # Durée après laquelle le timer doit s'arrêter (en ms)
                if interval > 0:
                    self.duree_total.setText(f"Temps total: {interval} ms")
                else:
                    QtWidgets.QMessageBox.warning(self, 'Invalid Input', 'Please enter a positive integer.')
            except ValueError:
                QtWidgets.QMessageBox.warning(self, 'Invalid Input', 'Please enter a valid integer.')

    def toggle_cursors(self, plot_graph):
        """Mettre en place ou retirer les curseurs sur le graphique
        """
        if self.flag_cursor:
            # Ajouter les curseurs
            self.v_line = pg.InfiniteLine(pen=pg.mkPen(width=3.5, color=(0, 255, 0)), angle=90, movable=True)
            self.h_line = pg.InfiniteLine(pen=pg.mkPen(width=3.5, color=(0, 255, 0)), angle=0, movable=True)
            # Connecter les signaux des curseurs pour afficher les coordonnées
            self.v_line.sigPositionChangeFinished.connect(self.update_cursor_position)
            self.h_line.sigPositionChangeFinished.connect(self.update_cursor_position)
            plot_graph.addItem(self.v_line, ignoreBounds=True)
            plot_graph.addItem(self.h_line, ignoreBounds=True)

        else:
            plot_graph.removeItem(self.v_line)
            plot_graph.removeItem(self.h_line)
        self.flag_cursor = not self.flag_cursor

    def update_cursor_position(self):
        x_pos = self.v_line.value()
        y_pos = self.h_line.value()
        self.statusBar.showMessage(f'Cursor Position : x={x_pos:.2f}, y={y_pos:.2f}')

    def yes_no(self):
        self.flag = not self.flag

    def reboot(self):
        self.curve.setData([], [])
        self.data_buffer.clear()
        self.data_buffer_B.clear()
        self.data_buffer_C.clear()
        self.data_buffer_AB.clear()
        self.data_buffer_AC.clear()
        self.data_buffer_ABC.clear()
        for i in [2, 3, 4, 5, 6] :
            curve = getattr(self, f'curve{i}', None)
            curve.setData([], [])

    def onMyToolBarButtonClick(self, s):
        print("click", s)

    def test(self):
        self.flag_timer = not self.flag_timer
        if self.flag_timer:
            self.timer_progress = QtCore.QTimer()
            self.timer_progress.timeout.connect(self.updateProgressBar)
            self.timer_progress.start(1000)  # Mettre à jour toutes les 100 ms
        else:
            self.timer_progress.stop()

    def updateProgressBar(self):
        self.progressBar.setValue(self.w2.A)
        self.progressBar_2.setValue(self.w2.B)
        self.progressBar_3.setValue(self.w2.C)
        self.progressBar_4.setValue(self.w2.ABC)
        self.w4.progressBar.setValue(self.w2.A)
        self.w4.progressBar_2.setValue(self.w2.B)
        self.w4.progressBar_3.setValue(self.w2.C)
        self.w4.progressBar_4.setValue(self.w2.ABC)
        self.w4.progressBar_5.setValue(self.w2.AB)
        self.w4.progressBar_6.setValue(self.w2.AC)

    def test2(self):
        self.flag_timer2 = not self.flag_timer2
        if self.flag_timer2:
            self.timer_progress2 = QtCore.QTimer()
            self.timer_progress2.timeout.connect(self.updatePlot)
            self.timer_progress2.start(1000)
        else:
            self.timer_progress2.stop()

    def updatePlot(self):
        self.label_11.setText(f'Nombres de points: {self.counter_points}')
        self.data_buffer.append(self.w2.A)
        self.data_buffer_B.append(self.w2.B)
        self.data_buffer_C.append(self.w2.C)
        self.data_buffer_AB.append(self.w2.AB)
        self.data_buffer_AC.append(self.w2.AC)
        self.data_buffer_ABC.append(self.w2.ABC)
        self.curve.setData(range(len(self.data_buffer)), self.data_buffer)
        self.curve2.setData(range(len(self.data_buffer_B)), self.data_buffer_B)
        self.curve3.setData(range(len(self.data_buffer_C)), self.data_buffer_C)
        self.curve4.setData(range(len(self.data_buffer_AB)), self.data_buffer_AB)
        self.curve5.setData(range(len(self.data_buffer_AC)), self.data_buffer_AC)
        self.curve6.setData(range(len(self.data_buffer_ABC)), self.data_buffer_ABC)

