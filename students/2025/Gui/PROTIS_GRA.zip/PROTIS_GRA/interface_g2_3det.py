"""
*************************************************
@author: Della Vittoria Louis
*************************************************

Le but de ce programme est de créer l'interface de gestion du g2 à trois détecteurs
et de pouvoir l'afficher en temps réel sur un graphique.

*************************************************

 *  Solec / https://solecgroup.wordpress.com/
 *  ProTIS / https://lense.institutoptique.fr/

"""

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QFont, QIcon
import pyqtgraph as pg
from serial import Serial, SerialException
import serial
import serial.tools.list_ports
import struct
import time
import random as rd
import interface_main

class SerialWorker(QtCore.QThread):
    data_received = QtCore.pyqtSignal(float)  # Signal émis lorsque des données g2 sont reçues
    counters_received = QtCore.pyqtSignal(int, int, int, int, int, int)  # Signal émis lorsque les compteurs sont reçus
    data_counterA = QtCore.pyqtSignal(int)  # Signal émis pour le compteur A

    def __init__(self, serial_port):
        super().__init__()
        self.serial_port = serial_port
        self.running = True

    def run(self):
        while self.running:
            try:
                # Lit les compteurs depuis le port série
                counter_A, counter_AB, counter_AC, counter_ABC, counter_B, counter_C = self.read_counters()

                if counter_A is not None:
                    # Affiche les résultats
                    print(f"Counter A: {counter_A}")
                    print(f"Counter AB: {counter_AB}")
                    print(f"Counter AC: {counter_AC}")
                    print(f"Counter ABC: {counter_ABC}")
                    print(f"Counter B: {counter_B}")
                    print(f"Counter C: {counter_C}")

                # Émet les compteurs reçus
                self.counters_received.emit(counter_A, counter_AB, counter_AC, counter_ABC, counter_B, counter_C)

                # Calcule la valeur du g2 à trois détecteurs
                self.g2_3detect = counter_ABC * counter_A / (counter_AB * counter_AC)
                print(f"La valeur du g2 à trois détecteurs est : {self.g2_3detect}")
                self.data_received.emit(self.g2_3detect)  # Émet la valeur calculée
                self.data_counterA.emit(counter_A)  # Émet la valeur du compteur A

                # Attend une seconde avant de lire à nouveau les données
                time.sleep(1)

            except KeyboardInterrupt:
                print("Fin du programme.")
                self.running = False

    def read_counters(self):
        # Lit 18 octets (3 octets par compteur)
        data = self.serial_port.read(18)
        print(data)

        if len(data) == 18:
            print('ok')
            # Convertit les 18 octets reçus en 6 compteurs (3 octets pour chaque compteur)
            counter_A = struct.unpack('>I', b'\x00' + data[0:3])[0] + 1  # Utilise '>I' pour un entier Big Endian
            counter_AB = struct.unpack('>I', b'\x00' + data[3:6])[0] + 1
            counter_AC = struct.unpack('>I', b'\x00' + data[6:9])[0] + 1
            counter_ABC = struct.unpack('>I', b'\x00' + data[9:12])[0] + 1
            counter_B = struct.unpack('>I', b'\x00' + data[12:15])[0] + 1
            counter_C = struct.unpack('>I', b'\x00' + data[15:18])[0] + 1
            return counter_A, counter_AB, counter_AC, counter_ABC, counter_B, counter_C
        else:
            print("Erreur de lecture des données")
            return None, None, None, None, None, None

class CounterStorageWorker(QtCore.QThread):
    counters_stored = QtCore.pyqtSignal(int, int, int, int)  # Signal émis lorsque les compteurs sont stockés

    def __init__(self):
        super().__init__()
        self.counter_A = 0
        self.counter_AB = 0
        self.counter_AC = 0
        self.counter_ABC = 0

    def store_counters(self, counter_A, counter_AB, counter_AC, counter_ABC):
        # Stocke les valeurs des compteurs
        self.counter_A = counter_A
        self.counter_AB = counter_AB
        self.counter_AC = counter_AC
        self.counter_ABC = counter_ABC
        self.counters_stored.emit(self.counter_A, self.counter_AB, self.counter_AC, self.counter_ABC)  # Émet les compteurs stockés

class Ui_MainWindow(QtCore.QObject):
    data_g2 = QtCore.pyqtSignal(float)  # Signal émis lorsque des données g2 sont reçues
    data_counter_A = QtCore.pyqtSignal(int)  # Signal émis pour le compteur A
    data_counter_multiple = QtCore.pyqtSignal(int, int, int, int, int, int)  # Signal émis pour plusieurs compteurs

    def __init__(self):
        super().__init__()
        serial_port = serial.tools.list_ports.comports()  # Liste tous les ports de communication série disponibles

        for port in serial_port:
            # Affiche chaque port de communication série
            print(f"{port.name} // {port.device} // D={port.description}")

        ser = serial.Serial("/dev/cu.usbmodem1103", baudrate=9600)  # Ouvre une connexion série
        print(ser)

        self.stack = 0
        self.data_buffer = []
        self.data_g2.connect(self.update_plot)  # Connecte le signal au slot de mise à jour du graphique

        self.A = 0
        self.AB = 0
        self.AC = 0
        self.ABC = 0
        self.B = 0
        self.C = 0

        self.serial_worker = SerialWorker(ser)  # Crée un worker pour la lecture série
        self.serial_worker.data_received.connect(self.data_g2.emit)  # Connecte le signal du worker au signal data_g2
        self.serial_worker.counters_received.connect(self.data_counter_multiple.emit)  # Connecte le signal des compteurs au signal data_counter_multiple
        self.data_counter_multiple.connect(self.update_progress_bar)  # Connecte le signal au slot de mise à jour des compteurs

        self.counter_storage_worker = CounterStorageWorker()  # Crée un worker pour le stockage des compteurs
        self.serial_worker.counters_received.connect(self.counter_storage_worker.store_counters)  # Connecte le signal des compteurs au worker de stockage
        self.counter_storage_worker.counters_stored.connect(self.send_counters_to_other_code)  # Connecte le signal des compteurs stockés à la méthode d'envoi

    def calculate_g2(self):
        self.serial_worker.start()  # Démarre le worker pour le calcul du g2

    def stop_g2(self):
        self.serial_worker.running = False  # Arrête le worker

    def update_progress_bar(self, counter_A, counter_AB, counter_AC, counter_ABC, counter_B, counter_C):
        # Met à jour les valeurs des compteurs
        self.A, self.AB, self.AC, self.ABC, self.B, self.C = counter_A, counter_AB, counter_AC, counter_ABC, counter_B, counter_C

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(770, 685)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(81, 21, 571, 41))
        self.label_7.setStyleSheet("    font-size: 15px;\n"
        "    font-weight: bold;\n"
        "    color: white;\n"
        "    background-color: grey;\n"
        "    border: 2px solid orange; /* Bordure verte */\n"
        "    border-radius: 5px; /* Coins arrondis */\n"
        "")
        self.label_7.setAlignment(QtCore.Qt.AlignCenter)
        self.label_7.setObjectName("label_7")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(119, 99, 501, 371))
        self.frame.setStyleSheet("border-radius: 10px;\n"
        "background-color: lightgrey\n"
        "")
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.verticalLayoutWidget = QtWidgets.QWidget(self.frame)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(10, 10, 481, 351))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(130, 90, 185, 16))
        self.label_8.setStyleSheet("    font-size: 12px;\n"
        "    font-weight: bold;\n"
        "    color: white;\n"
        "    background-color: grey;\n"
        "    border: 2px solid grey; /* Bordure verte */\n"
        "    border-radius: 8px; /* Coins arrondis */\n"
        "")
        self.label_8.setObjectName("label_8")
        self.frame_2 = QtWidgets.QFrame(self.centralwidget)
        self.frame_2.setGeometry(QtCore.QRect(120, 480, 501, 171))
        self.frame_2.setStyleSheet("\n"
        "border-radius: 10px;\n"
        "background-color: lightgrey\n"
        "")
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.verticalLayoutWidget_5 = QtWidgets.QWidget(self.frame_2)
        self.verticalLayoutWidget_5.setGeometry(QtCore.QRect(20, 10, 461, 151))
        self.verticalLayoutWidget_5.setObjectName("verticalLayoutWidget_5")
        self.verticalLayout_6 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_5)
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget_5)
        self.label_2.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.label_2.setAutoFillBackground(False)
        self.label_2.setStyleSheet("QLabel {\n"
        "    font-size: 16px;\n"
        "    font-weight: bold;\n"
        "    color: white;\n"
        "    background-color: grey;\n"
        "    border: 2px solid orange; /* Bordure verte */\n"
        "    border-radius: 10px; /* Coins arrondis */\n"
        "    padding: 5px; /* Espacement interne */\n"
        "}")
        self.label_2.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.label_2.setFrameShadow(QtWidgets.QFrame.Plain)
        self.label_2.setLineWidth(0)
        self.label_2.setMidLineWidth(0)
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setWordWrap(False)
        self.label_2.setObjectName("label_2")
        self.verticalLayout_6.addWidget(self.label_2)
        self.pushButton_3 = QtWidgets.QPushButton(self.verticalLayoutWidget_5)
        self.pushButton_3.setStyleSheet("QPushButton {\n"
        "    background-color: #4CAF50;\n"
        "    color: white;\n"
        "    font-size: 14px;\n"
        "    font-weight: bold;\n"
        "    border: 2px solid #2E7D32;\n"
        "    border-radius: 5px;\n"
        "    padding: 1px;\n"
        "}\n"
        "\n"
        "QPushButton:hover {\n"
        "    background-color: #45a049;\n"
        "    border-color: #1B5E20;\n"
        "}\n"
        "\n"
        "QPushButton:pressed {\n"
        "    background-color: #388E3C;\n"
        "    border-color: #1B5E20;\n"
        "}\n"
        "\n"
        "")
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_3.clicked.connect(self.calculate_g2)  # Connecte le bouton au démarrage du calcul du g2
        self.verticalLayout_6.addWidget(self.pushButton_3)
        self.pushButton_4 = QtWidgets.QPushButton(self.verticalLayoutWidget_5)
        self.pushButton_4.setStyleSheet("QPushButton {\n"
        "    background-color: #4CAF50;\n"
        "    color: white;\n"
        "    font-size: 14px;\n"
        "    font-weight: bold;\n"
        "    border: 2px solid #2E7D32;\n"
        "    border-radius: 5px;\n"
        "    padding: 1px;\n"
        "}\n"
        "\n"
        "QPushButton:hover {\n"
        "    background-color: #45a049;\n"
        "    border-color: #1B5E20;\n"
        "}\n"
        "\n"
        "QPushButton:pressed {\n"
        "    background-color: #388E3C;\n"
        "    border-color: #1B5E20;\n"
        "}\n"
        "\n"
        "")
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_4.clicked.connect(self.stop_g2)  # Connecte le bouton à l'arrêt du calcul du g2
        self.verticalLayout_6.addWidget(self.pushButton_4)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 770, 24))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.pushButton_5 = QtWidgets.QPushButton(self.verticalLayoutWidget_5)
        self.pushButton_5.setStyleSheet("QPushButton {\n"
        "    background-color: #4CAF50;\n"
        "    color: white;\n"
        "    font-size: 14px;\n"
        "    font-weight: bold;\n"
        "    border: 2px solid #2E7D32;\n"
        "    border-radius: 5px;\n"
        "    padding: 1px;\n"
        "}\n"
        "\n"
        "QPushButton:hover {\n"
        "    background-color: #45a049;\n"
        "    border-color: #1B5E20;\n"
        "}\n"
        "\n"
        "QPushButton:pressed {\n"
        "    background-color: #388E3C;\n"
        "    border-color: #1B5E20;\n"
        "}\n"
        "\n"
        "")
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_5.clicked.connect(self.save_plot)  # Connecte le bouton à l'enregistrement du graphique
        self.pushButton_5.setText("Enregistrer l'image")
        self.verticalLayout_6.addWidget(self.pushButton_5)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        # Configuration du graphique avec pyqtgraph
        self.plot_graph = pg.PlotWidget()
        self.plot_graph.setBackground("k")
        self.plot_graph.setLabel("left", "Valeur de la mesure")
        self.plot_graph.setLabel("bottom", "Temps (x1s)")
        self.plot_graph.setTitle("Affichage du calcul du 3 à trois détecteurs")
        self.plot_graph.showGrid(x=True, y=True)

        self.curve = self.plot_graph.plot(
            [],
            [],
            pen=pg.mkPen(width=5, color=(127, 127, 0)),
            name="Points de coïncidences",
            symbol="+",
            symbolSize=5,
            symbolBrush="b",
        )

        self.verticalLayout.addWidget(self.plot_graph)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Interface g2 à trois détecteurs"))
        self.label_7.setText(_translate("MainWindow", "Calcul et affichage du g2"))
        self.label_8.setText(_translate("MainWindow", "Représentation graphique g2"))
        self.label_2.setText(_translate("MainWindow", "Contrôle de la fenêtre du g2"))
        self.pushButton_3.setText(_translate("MainWindow", "Démarrer le calcul du g2"))
        self.pushButton_4.setText(_translate("MainWindow", "Stopper le calcul du g2"))

    def update_plot(self, value):
        """Met à jour le graphique et le compteur de points"""
        self.data_buffer.append(value)
        self.curve.setData(range(len(self.data_buffer)), self.data_buffer)

    def save_plot(self):
        self.stack += 1
        exporter = pg.exporters.ImageExporter(self.plot_graph.plotItem)
        # Enregistre le graphique dans un fichier
        exporter.export(f'{self.stack}_Graphique_g2.png')

    def send_counters_to_other_code(self, counter_A, counter_AB, counter_AC, counter_ABC):
        # Implémentez ici le code pour envoyer les valeurs des compteurs à un autre code
        print(f"Sending counters to other code: A={counter_A}, AB={counter_AB}, AC={counter_AC}, ABC={counter_ABC}")

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
