"""
*************************************************
@author: Della Vittoria Louis
*************************************************

Ce programme permet de gérer le contrôle de la 
cale pièzo-électrique. Ce code utilise le module
Kenesis de Thorlabs. 

*************************************************

 *  Solec / https://solecgroup.wordpress.com/
 *  ProTIS / https://lense.institutoptique.fr/

"""


from PyQt5 import QtCore, QtGui, QtWidgets
# from class_piezo import *  # À décommenter pour intégrer la classe réelle de contrôle piezo
import time

# Classe de travail (thread) pour exécuter des mouvements automatisés de la cale
class AutomationWorker(QtCore.QThread):
    def __init__(self, controller_piezo):
        super().__init__()
        # self.controller_piezo = controller_piezo  # À activer quand le contrôleur réel est utilisé

    def run(self):
        # Simulation de mesure automatisée de la cale piezo entre 0 et 19 µm
        mesure = []
        for i in range(0, 20):
            mesure.append(i)
            print(i)  # Affiche la valeur courante
            time.sleep(1)  # Pause de 1 seconde entre chaque mouvement
            # self.controller_piezo.GoToDistance(i)  # Commande réelle du déplacement
        # self.controller_piezo.set_zero()  # Réinitialisation finale

# Interface utilisateur principale de la fenêtre de contrôle
class Ui_MainWindow2(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.controller_piezo = None  # Contrôleur piezo à définir/initialiser plus tard

    def setupUi(self, MainWindow2):
        # Configuration de la fenêtre principale
        MainWindow2.setObjectName("Fenêtre de contrôle de la cale piezo-électrique")
        MainWindow2.resize(470, 700)
        MainWindow2.setStyleSheet("background-color:white")

        self.centralwidget = QtWidgets.QWidget(MainWindow2)
        self.centralwidget.setObjectName("centralwidget")

        # Création d'un cadre pour contenir les éléments
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setGeometry(QtCore.QRect(30, 10, 411, 641))
        self.frame.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setLineWidth(0)
        self.frame.setObjectName("frame")

        # Image de l'appareil
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setGeometry(QtCore.QRect(30, 50, 351, 351))
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap("/Users/louisdellavittoria/Desktop/Etudes/2_2A/Projet/PROTIS/KPC101.jpg"))
        self.label.setScaledContents(True)
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")

        # Titre de la fenêtre
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setGeometry(QtCore.QRect(20, 20, 371, 21))
        self.label_2.setStyleSheet("font-size: 15px; font-weight: bold; color: white; background-color: grey; border: 2px solid orange; border-radius: 5px;")
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")

        # Deuxième cadre : contient les contrôles de déplacement
        self.frame_2 = QtWidgets.QFrame(self.frame)
        self.frame_2.setGeometry(QtCore.QRect(30, 430, 351, 201))
        self.frame_2.setStyleSheet("border-radius: 10px; background-color: lightgrey")
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")

        # Layout vertical dans le cadre
        self.verticalLayoutWidget_3 = QtWidgets.QWidget(self.frame_2)
        self.verticalLayoutWidget_3.setGeometry(QtCore.QRect(10, 10, 331, 181))
        self.verticalLayoutWidget_3.setObjectName("verticalLayoutWidget_3")
        self.verticalLayout_6 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_3)
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_6.setObjectName("verticalLayout_6")

        # Première ligne : sélection de la valeur de déplacement
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")

        # Texte "Déplacement (µm)"
        self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget_3)
        self.label_3.setStyleSheet("font-size: 14px; font-weight: bold; color: white; background-color: grey; border: 2px solid grey; border-radius: 8px;")
        self.label_3.setObjectName("label_3")
        self.horizontalLayout.addWidget(self.label_3)

        # Champ numérique pour entrer la valeur de déplacement
        self.doubleSpinBox = QtWidgets.QDoubleSpinBox(self.verticalLayoutWidget_3)
        self.doubleSpinBox.setStyleSheet("QDoubleSpinBox { background-color: #2E3440; color: white; font-weight: bold; border: 2px solid black; border-radius: 8px; padding: 5px; font-size: 15px; }"
                                         "QDoubleSpinBox::up-button { background-color: #4CAF50; border-radius: 5px; }"
                                         "QDoubleSpinBox::down-button { background-color: #fc3535; border-radius: 5px; }")
        self.doubleSpinBox.setAlignment(QtCore.Qt.AlignCenter)
        self.doubleSpinBox.setReadOnly(False)
        self.doubleSpinBox.setButtonSymbols(QtWidgets.QAbstractSpinBox.UpDownArrows)
        self.doubleSpinBox.setObjectName("doubleSpinBox")
        self.doubleSpinBox.valueChanged.connect(self.set_value)  # Connecte le changement de valeur à une méthode
        self.horizontalLayout.addWidget(self.doubleSpinBox)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        self.verticalLayout_6.addLayout(self.verticalLayout_2)

        # Boutons d'action
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")

        # Bouton pour déplacer la cale à la position spécifiée
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget_3)
        self.pushButton.setStyleSheet("QPushButton { background-color: #4CAF50; color: white; font-size: 14px; font-weight: bold; border: 2px solid #2E7D32; border-radius: 5px; }"
                                      "QPushButton:hover { background-color: #45a049; }"
                                      "QPushButton:pressed { background-color: #388E3C; }")
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(self.go_to_distance)
        self.verticalLayout_3.addWidget(self.pushButton)

        # Bouton pour réinitialiser la position
        self.pushButton_2 = QtWidgets.QPushButton(self.verticalLayoutWidget_3)
        self.pushButton_2.setStyleSheet(self.pushButton.styleSheet())
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.clicked.connect(self.init_piezo)
        self.verticalLayout_3.addWidget(self.pushButton_2)

        # Bouton pour lancer le déplacement automatique 0 → 20
        self.pushButton_3 = QtWidgets.QPushButton(self.verticalLayoutWidget_3)
        self.pushButton_3.setStyleSheet(self.pushButton.styleSheet())
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_3.clicked.connect(self.start_automation)
        self.verticalLayout_3.addWidget(self.pushButton_3)

        self.verticalLayout_6.addLayout(self.verticalLayout_3)

        # Texte "Contrôles"
        self.label_8 = QtWidgets.QLabel(self.frame)
        self.label_8.setGeometry(QtCore.QRect(40, 420, 81, 16))
        self.label_8.setStyleSheet("font-size: 12px; font-weight: bold; color: white; background-color: grey; border: 2px solid grey; border-radius: 8px;")
        self.label_8.setAlignment(QtCore.Qt.AlignCenter)
        self.label_8.setObjectName("label_8")

        # Bouton d'information (non connecté à une action)
        self.pushButton_4 = QtWidgets.QPushButton(self.frame)
        self.pushButton_4.setGeometry(QtCore.QRect(280, 390, 91, 16))
        self.pushButton_4.setStyleSheet(self.label_8.styleSheet())
        self.pushButton_4.setObjectName("pushButton_4")

        # Barres de menu et de statut
        MainWindow2.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow2)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 470, 36))
        self.menubar.setObjectName("menubar")
        MainWindow2.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow2)
        self.statusbar.setObjectName("statusbar")
        MainWindow2.setStatusBar(self.statusbar)

        # Configuration des textes des boutons et labels
        self.retranslateUi(MainWindow2)
        QtCore.QMetaObject.connectSlotsByName(MainWindow2)

    def retranslateUi(self, MainWindow2):
        # Traduction des textes dans l'interface
        _translate = QtCore.QCoreApplication.translate
        MainWindow2.setWindowTitle(_translate("MainWindow2", "Fenêtre de contrôle de la cale piezo-électrique"))
        self.label_2.setText(_translate("MainWindow2", "Fenêtre de contrôle de la cale piezo-électrique"))
        self.label_3.setText(_translate("MainWindow2", "Déplacement (µm) :"))
        self.pushButton.setText(_translate("MainWindow2", "Déplacer la cale piezo-électrique"))
        self.pushButton_2.setText(_translate("MainWindow2", "Revenir à la position initiale"))
        self.pushButton_3.setText(_translate("MainWindow2", "Déplacement automatisé 0 --> 20"))
        self.label_8.setText(_translate("MainWindow2", "Contrôles"))
        self.pushButton_4.setText(_translate("MainWindow2", "Infos piezo"))

    # Méthode appelée lorsque l'utilisateur change la valeur du spinbox
    def set_value(self):
        self.value_distance = self.doubleSpinBox.value()
        print(self.value_distance)

    # Bouton : réinitialisation de la position de la cale
    def init_piezo(self):
        print("Initialisation de la cale piezo-électrique")
        self.controller_piezo.set_zero()
        print("Initialisation terminée")

    # Bouton : déplacer la cale à la distance indiquée
    def go_to_distance(self):
        print("Déplacement de la cale piezo-électrique")
        print(self.value_distance)
        self.controller_piezo.GoToDistance(self.value_distance)
        print("Déplacement terminé")

    # Bouton : lancer le déplacement automatisé
    def start_automation(self):
        self.automation_worker = AutomationWorker(self.controller_piezo)
        self.automation_worker.start()

# Point d'entrée du programme
if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow2 = QtWidgets.QMainWindow()
    ui = Ui_MainWindow2()
    ui.setupUi(MainWindow2)
    MainWindow2.show()
    sys.exit(app.exec_())