"""
*************************************************
@author: Della Vittoria Louis
*************************************************

Le but de ce programme est de créer l'interface permettant d'afficher et 
d'actualiser les différentes jauges de comptage. 
*************************************************

 *  Solec / https://solecgroup.wordpress.com/
 *  ProTIS / https://lense.institutoptique.fr/

"""

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QFont, QIcon
import pyqtgraph as pg
from serial import Serial, SerialException
import random
import time
import interface_piezo
import interface_g2_3det
import interface_g2_2det
import struct
import interface_g2_3det


class Ui_MainWindow(QtCore.QObject):
        '''
        Cette classe permet de créer l'interface de la fenêtre d'affichage des jauges de comptage.
        '''
        def __init__(self):

                self.flag_timer = False
                
        def setupUi(self, MainWindow):
                MainWindow.setObjectName("MainWindow")
                MainWindow.resize(669, 641)
                self.centralwidget = QtWidgets.QWidget(MainWindow)
                self.centralwidget.setObjectName("centralwidget")
                self.frame_3 = QtWidgets.QFrame(self.centralwidget)
                self.frame_3.setGeometry(QtCore.QRect(110, 100, 441, 451))
                self.frame_3.setStyleSheet("\n"
                "border-radius: 10px;\n"
                "background-color: lightgrey\n"
                "")
                self.frame_3.setFrameShape(QtWidgets.QFrame.StyledPanel)
                self.frame_3.setFrameShadow(QtWidgets.QFrame.Raised)
                self.frame_3.setObjectName("frame_3")
                self.verticalLayoutWidget_6 = QtWidgets.QWidget(self.frame_3)
                self.verticalLayoutWidget_6.setGeometry(QtCore.QRect(10, 10, 411, 429))
                self.verticalLayoutWidget_6.setObjectName("verticalLayoutWidget_6")
                self.verticalLayout_10 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_6)
                self.verticalLayout_10.setContentsMargins(0, 0, 0, 0)
                self.verticalLayout_10.setObjectName("verticalLayout_10")
                self.verticalLayout_4 = QtWidgets.QVBoxLayout()
                self.verticalLayout_4.setObjectName("verticalLayout_4")
                self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
                self.label_2.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
                self.label_2.setAutoFillBackground(False)
                self.label_2.setStyleSheet("    font-size: 16px;\n"
                "    font-weight: bold;\n"
                "    color: white;\n"
                "    background-color: grey;\n"
                "    border: 2px solid orange; /* Bordure verte */\n"
                "    border-radius: 10px; /* Coins arrondis */\n"
                "    padding: 5px; /* Espacement interne */")
                self.label_2.setFrameShape(QtWidgets.QFrame.Box)
                self.label_2.setFrameShadow(QtWidgets.QFrame.Raised)
                self.label_2.setLineWidth(2)
                self.label_2.setMidLineWidth(1)
                self.label_2.setAlignment(QtCore.Qt.AlignCenter)
                self.label_2.setWordWrap(False)
                self.label_2.setObjectName("label_2")
                self.verticalLayout_4.addWidget(self.label_2)
                self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
                self.horizontalLayout_2.setObjectName("horizontalLayout_2")
                self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
                self.label_3.setStyleSheet("    font-size: 12px;\n"
                "    font-weight: bold;\n"
                "    color: white;\n"
                "    background-color: grey;\n"
                "    border: 2px solid grey; /* Bordure verte */\n"
                "    border-radius: 8px; /* Coins arrondis */\n"
                "")
                self.label_3.setObjectName("label_3")
                self.horizontalLayout_2.addWidget(self.label_3)
                spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
                self.horizontalLayout_2.addItem(spacerItem)
                self.verticalLayout_4.addLayout(self.horizontalLayout_2)
                self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
                self.horizontalLayout_3.setObjectName("horizontalLayout_3")
                self.progressBar = QtWidgets.QProgressBar(self.verticalLayoutWidget_6)
                self.progressBar.setMaximum(1000000)
                self.progressBar.setFormat("%v")

                self.progressBar.setStyleSheet("""
                QProgressBar {
                        color: black;
                        font-weight: bold;
                        border-style: solid;
                        border-color: grey;
                        border-radius: 7px;
                        border-width: 2px;
                        text-align: center;
                }

                QProgressBar::chunk {
                        width: 4px;
                        background-color: green;
                        margin: 3px;
                }
                """)
                self.progressBar.setAlignment(QtCore.Qt.AlignCenter)
                self.progressBar.setObjectName("progressBar")
                self.horizontalLayout_3.addWidget(self.progressBar)
                self.verticalLayout_4.addLayout(self.horizontalLayout_3)
                self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
                self.horizontalLayout_4.setObjectName("horizontalLayout_4")
                self.label_4 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
                self.label_4.setStyleSheet("    font-size: 12px;\n"
                "    font-weight: bold;\n"
                "    color: white;\n"
                "    background-color: grey;\n"
                "    border: 2px solid grey; /* Bordure verte */\n"
                "    border-radius: 8px; /* Coins arrondis */\n"
                "")
                self.label_4.setObjectName("label_4")
                self.horizontalLayout_4.addWidget(self.label_4)
                spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
                self.horizontalLayout_4.addItem(spacerItem1)
                self.verticalLayout_4.addLayout(self.horizontalLayout_4)
                self.verticalLayout_9 = QtWidgets.QVBoxLayout()
                self.verticalLayout_9.setObjectName("verticalLayout_9")
                self.progressBar_2 = QtWidgets.QProgressBar(self.verticalLayoutWidget_6)
                self.progressBar_2.setMaximum(1000000)
                self.progressBar_2.setFormat("%v")
                self.progressBar_2.setStyleSheet("""
                QProgressBar {
                color: black;
                font-weight: bold;
                border-style: solid;
                border-color: grey;
                border-radius: 7px;
                border-width: 2px;
                text-align: center;
                }

                QProgressBar::chunk {
                width: 4px;
                background-color: green;
                margin: 3px;
                 }
                 """)
                self.progressBar_2.setAlignment(QtCore.Qt.AlignCenter)
                self.progressBar_2.setObjectName("progressBar_2")
                self.verticalLayout_9.addWidget(self.progressBar_2)
                self.verticalLayout_4.addLayout(self.verticalLayout_9)
                self.horizontalLayout_5 = QtWidgets.QHBoxLayout()
                self.horizontalLayout_5.setObjectName("horizontalLayout_5")
                self.label_5 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
                self.label_5.setStyleSheet("    font-size: 12px;\n"
                "    font-weight: bold;\n"
                "    color: white;\n"
                "    background-color: grey;\n"
                "    border: 2px solid grey; /* Bordure verte */\n"
                "    border-radius: 8px; /* Coins arrondis */\n"
                "")
                self.label_5.setObjectName("label_5")
                self.horizontalLayout_5.addWidget(self.label_5)
                spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
                self.horizontalLayout_5.addItem(spacerItem2)
                self.verticalLayout_4.addLayout(self.horizontalLayout_5)
                self.verticalLayout_8 = QtWidgets.QVBoxLayout()
                self.verticalLayout_8.setObjectName("verticalLayout_8")
                self.progressBar_3 = QtWidgets.QProgressBar(self.verticalLayoutWidget_6)
                self.progressBar_3.setMaximum(1000000)
                self.progressBar_3.setFormat("%v")
                self.progressBar_3.setStyleSheet("""
                QProgressBar {
                color: black;
                font-weight: bold;
                border-style: solid;
                border-color: grey;
                border-radius: 7px;
                border-width: 2px;
                text-align: center;
                }

                QProgressBar::chunk {
                width: 4px;
                background-color: green;
                margin: 3px;
                 }
                 """)
                self.progressBar_3.setAlignment(QtCore.Qt.AlignCenter)
                self.progressBar_3.setObjectName("progressBar_3")
                self.verticalLayout_8.addWidget(self.progressBar_3)
                self.verticalLayout_4.addLayout(self.verticalLayout_8)
                self.horizontalLayout_6 = QtWidgets.QHBoxLayout()
                self.horizontalLayout_6.setObjectName("horizontalLayout_6")
                self.label_6 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
                self.label_6.setStyleSheet("    font-size: 12px;\n"
                "    font-weight: bold;\n"
                "    color: white;\n"
                "    background-color: grey;\n"
                "    border: 2px solid grey; /* Bordure verte */\n"
                "    border-radius: 8px; /* Coins arrondis */\n"
                "")
                self.label_6.setObjectName("label_6")
                self.horizontalLayout_6.addWidget(self.label_6)
                spacerItem3 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
                self.horizontalLayout_6.addItem(spacerItem3)
                self.verticalLayout_4.addLayout(self.horizontalLayout_6)
                self.verticalLayout_2 = QtWidgets.QVBoxLayout()
                self.verticalLayout_2.setObjectName("verticalLayout_2")
                self.progressBar_5 = QtWidgets.QProgressBar(self.verticalLayoutWidget_6)
                self.progressBar_5.setMaximum(1000000)
                self.progressBar_5.setFormat("%v")
                self.progressBar_5.setStyleSheet("""
                QProgressBar {
                color: black;
                font-weight: bold;
                border-style: solid;
                border-color: grey;
                border-radius: 7px;
                border-width: 2px;
                text-align: center;
                }

                QProgressBar::chunk {
                width: 4px;
                background-color: green;
                margin: 3px;
                 }
                 """)
                self.progressBar_5.setAlignment(QtCore.Qt.AlignCenter)
                self.progressBar_5.setObjectName("progressBar_5")
                self.verticalLayout_2.addWidget(self.progressBar_5)
                self.verticalLayout_4.addLayout(self.verticalLayout_2)
                self.horizontalLayout_12 = QtWidgets.QHBoxLayout()
                self.horizontalLayout_12.setObjectName("horizontalLayout_12")
                self.label_9 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
                self.label_9.setStyleSheet("    font-size: 12px;\n"
                "    font-weight: bold;\n"
                "    color: white;\n"
                "    background-color: grey;\n"
                "    border: 2px solid grey; /* Bordure verte */\n"
                "    border-radius: 8px; /* Coins arrondis */\n"
                "")
                self.label_9.setObjectName("label_9")
                self.horizontalLayout_12.addWidget(self.label_9)
                spacerItem4 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
                self.horizontalLayout_12.addItem(spacerItem4)
                self.verticalLayout_4.addLayout(self.horizontalLayout_12)
                self.verticalLayout_5 = QtWidgets.QVBoxLayout()
                self.verticalLayout_5.setObjectName("verticalLayout_5")
                self.progressBar_6 = QtWidgets.QProgressBar(self.verticalLayoutWidget_6)
                self.progressBar_6.setMaximum(1000000)
                self.progressBar_6.setFormat("%v")
                self.progressBar_6.setStyleSheet("""
                QProgressBar {
                color: black;
                font-weight: bold;
                border-style: solid;
                border-color: grey;
                border-radius: 7px;
                border-width: 2px;
                text-align: center;
                }

                QProgressBar::chunk {
                width: 4px;
                background-color: green;
                margin: 3px;
                 }
                 """)
                self.progressBar_6.setAlignment(QtCore.Qt.AlignCenter)
                self.progressBar_6.setObjectName("progressBar_6")
                self.verticalLayout_5.addWidget(self.progressBar_6)
                self.verticalLayout_4.addLayout(self.verticalLayout_5)
                self.horizontalLayout_11 = QtWidgets.QHBoxLayout()
                self.horizontalLayout_11.setObjectName("horizontalLayout_11")
                self.label_8 = QtWidgets.QLabel(self.verticalLayoutWidget_6)
                self.label_8.setStyleSheet("    font-size: 12px;\n"
                "    font-weight: bold;\n"
                "    color: white;\n"
                "    background-color: grey;\n"
                "    border: 2px solid grey; /* Bordure verte */\n"
                "    border-radius: 8px; /* Coins arrondis */\n"
                "")
                self.label_8.setObjectName("label_8")
                self.horizontalLayout_11.addWidget(self.label_8)
                spacerItem5 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
                self.horizontalLayout_11.addItem(spacerItem5)
                self.verticalLayout_4.addLayout(self.horizontalLayout_11)
                self.horizontalLayout = QtWidgets.QHBoxLayout()
                self.horizontalLayout.setObjectName("horizontalLayout")
                self.progressBar_4 = QtWidgets.QProgressBar(self.verticalLayoutWidget_6)
                self.progressBar_4.setMaximum(10000000)
                self.progressBar_4.setFormat("%v")
                self.progressBar_4.setStyleSheet("""
                QProgressBar {
                color: black;
                font-weight: bold;
                border-style: solid;
                border-color: grey;
                border-radius: 7px;
                border-width: 2px;
                text-align: center;
                }

                QProgressBar::chunk {
                width: 4px;
                background-color: green;
                margin: 3px;
                 }
                 """)
                self.progressBar_4.setAlignment(QtCore.Qt.AlignCenter)
                self.progressBar_4.setObjectName("progressBar_4")
                self.horizontalLayout.addWidget(self.progressBar_4)
                self.verticalLayout_4.addLayout(self.horizontalLayout)
                self.verticalLayout_10.addLayout(self.verticalLayout_4)
                self.label_10 = QtWidgets.QLabel(self.centralwidget)
                self.label_10.setGeometry(QtCore.QRect(60, 30, 531, 41))
                self.label_10.setStyleSheet("    font-size: 15px;\n"
                "    font-weight: bold;\n"
                "    color: white;\n"
                "    background-color: grey;\n"
                "    border: 2px solid orange; /* Bordure verte */\n"
                "    border-radius: 5px; /* Coins arrondis */\n"
                "")
                self.label_10.setAlignment(QtCore.Qt.AlignCenter)
                self.label_10.setObjectName("label_10")
                MainWindow.setCentralWidget(self.centralwidget)
                self.menubar = QtWidgets.QMenuBar(MainWindow)
                self.menubar.setGeometry(QtCore.QRect(0, 0, 669, 24))
                self.menubar.setObjectName("menubar")
                MainWindow.setMenuBar(self.menubar)
                self.statusbar = QtWidgets.QStatusBar(MainWindow)
                self.statusbar.setObjectName("statusbar")
                MainWindow.setStatusBar(self.statusbar)

                
                self.retranslateUi(MainWindow)
                QtCore.QMetaObject.connectSlotsByName(MainWindow)

        def retranslateUi(self, MainWindow):
                _translate = QtCore.QCoreApplication.translate
                MainWindow.setWindowTitle(_translate("MainWindow", "Jauges de comptage"))
                self.label_2.setText(_translate("MainWindow", "Jauges de comptage"))
                self.label_3.setText(_translate("MainWindow", "Jauge A : "))
                self.label_4.setText(_translate("MainWindow", "Jauge B : "))
                self.label_5.setText(_translate("MainWindow", "Jauge C : "))
                self.label_6.setText(_translate("MainWindow", "Jauge AB : "))
                self.label_9.setText(_translate("MainWindow", "Jauge AC : "))
                self.label_8.setText(_translate("MainWindow", "Jauge ABC : "))
                self.label_10.setText(_translate("MainWindow", "Fenêtre d\'affichage des jauges"))
        
